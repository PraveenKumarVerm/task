import React from "react";
// import logo from './logo.svg';
import "./App.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Registration from "./Components/Registeration";
import { Route, BrowserRouter as Router, Routes } from "react-router-dom";
import Home from "./Components/Home";
import Login from "./Components/Login";
import List from "./Components/List";


function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route exact path="/" element={<List />}></Route>
          <Route exact path="/home" element={<Home />}></Route>
          <Route exact path="/registration" element={<Registration />}></Route>
          <Route exact path="/login" element={<Login />}></Route>

        </Routes>
      </Router>
    </div>
  );
}

export default App;

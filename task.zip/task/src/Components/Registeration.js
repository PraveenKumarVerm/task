import React, { useState } from "react";
import { Form, Alert } from "react-bootstrap";
import Login from "./Login";

function Registration() {
  const [firstname, setFirstName] = useState("");
  const [lastname, setLastName] = useState("");
  const [DateofBirth, setDateofBirth] = useState("");
  const [city, setCity] = useState("");
  const [state, setState] = useState("");
  const [address, setAddress] = useState("");
  const [age, setAge] = useState("");
  const [designation, setDesignation] = useState("");

  const [flag, setFlag] = useState(false);
  const [login, setLogin] = useState(true);
  


  function handleFormSubmit(e) {
    e.preventDefault();

    if (!firstname || !lastname ||!DateofBirth || !city || !state || !age || !address || !designation) {
      setFlag(true);
    } else {
      setFlag(false);
      localStorage.setItem("sanskarEmail", JSON.stringify("  "));
      localStorage.setItem(
        "sanskarPassword",
        JSON.stringify("  ")
      );
      console.log("Saved in Local Storage");

      setLogin(!login);
    }
  }

  function handleClick() {
    setLogin(!login);
  }

 
  

  return (
    <>
 
        <div>
          {" "}
          {login ? (
            <form onSubmit={handleFormSubmit}>
              <h3>Register</h3>

              <div className="form-group">
                <label>First Name</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter First Name"
                  name="firstname"
                  onChange={(event) => setFirstName(event.target.value)}
                />
              </div>

              <div className="form-group">
                <label>Last Name</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter Last Name"
                  name="lastname"
                  onChange={(event) => setLastName(event.target.value)}
                />
              </div>

              <div className="form-group">
                <label>Date of Birth</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter DOB Name"
                  name="DateofBirth"
                  onChange={(event) => setDateofBirth(event.target.value)}
                />
              </div>

              <div className="form-group">
                <label>Age</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter Age"
                  name="age"
                  onChange={(event) => setAge(event.target.value)}
                />
              </div>

              <div className="form-group">
                <label>City</label>
                <Form.Control
                  as="select"
                  onChange={(event) => setCity(event.target.value)}
                >
                  <option>Select</option>
                  <option>Indore</option>
                  <option>Bhopal</option>
                  <option>Ujjain</option>
                  <option>Goa</option>
                </Form.Control>
              </div>


              <div className="form-group">
                <label>Choose your State</label>
                <Form.Control
                  as="select"
                  onChange={(event) => setState(event.target.value)}
                >
                  <option>Select</option>
                  <option>MP</option>
                  <option>CG</option>
                  <option>UP</option>
                  <option>AP</option>
                </Form.Control>
              </div>


              <div className="form-group">
                <label>Address</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter Address"
                  onChange={(event) => setAddress(event.target.value)}
                />
              </div>


              <div className="form-group">
                <label>Choose your Designation</label>
                <Form.Control
                  as="select"
                  onChange={(event) => setDesignation(event.target.value)}
                >
                  <option>Select</option>
                  <option>Front End Developer</option>
                  <option>Back End Developer</option>
                  <option>AI</option>
                  <option>Full Stack Developer</option>
                </Form.Control>
              </div>

              <button type="submit" className="btn btn-dark btn-lg btn-block">
                Register
              </button>
              <p onClick={handleClick} className="forgot-password text-right">
                Already registered{" "}log in?
                
              </p>
              {flag && (
                <Alert color="primary" variant="danger">
                  I got it you are in hurry! But every Field is important!
                </Alert>
              )}
            </form>
          ) : (
            <Login />
          )}
        </div>
    
    </>
  );
}

export default Registration;

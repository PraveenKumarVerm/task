export const GETDATA = 'GETDATA'




import http from "../../axios";
class dataservice {
  getAll() {
    return http.get("/posts");
  }
}
export default new dataservice();

import { combineReducers } from "redux";
import datareducers from "./reducers";
export default combineReducers({
  datareducers,
});

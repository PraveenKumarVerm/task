import { GETDATA } from "../Constant/constant";
const initialState = [];
function datareducers(tutorials = initialState, action) {
  const { type, payload } = action;
  switch (type) {
    case GETDATA:
      return [...tutorials, payload];
    default:
      return tutorials;
  }
}
export default datareducers;

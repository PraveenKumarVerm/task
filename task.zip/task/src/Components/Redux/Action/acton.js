import { GETDATA } from "../Constant/constant";
import dataservice from "../Services/services";
export const getAlldata = () => async (dispatch) => {
  try {
    const res = await dataservice.getAll({});
    dispatch({
      type: GETDATA,
      payload: res.data,
    });
    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};

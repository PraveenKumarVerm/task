import React, { useState, useEffect } from "react";
import { Form, Alert } from "react-bootstrap";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { getAlldata } from "./Redux/Action/acton";
function List(props) {
  const [list, setlist] = useState([]);
  const [listupdated, setlistupdated] = useState([]);

  const getRecord = () => {
    props
      .getAlldata()
      .then((data) => {
        setlist(data);
        setlistupdated(data);
      })
      .catch((e) => {
        console.log(e);
      });
  };

  const DeleteRecord = (id) => {
    console.log(id);
    var result = [];
    return (result = list.filter((item) => item.id != id)), setlist(result);
  };
  const filterData = (data) => {
    console.log(data);
    if (data != "") {
      let result = list.filter(
        (item) =>
          item.body.toLowerCase().indexOf(data) !== -1 ||
          item.title.toLowerCase().indexOf(data) !== -1
      );
      setlist(result);
    } else {
      setlist(listupdated);
    }
  };

  useEffect(() => {
    getRecord();
  }, []);
  return (
    <div>
      <div>
        <input type="text" onChange={(e) => filterData(e.target.value)}></input>
      </div>
      <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Tittle</th>
            <th scope="col">Body</th>
          </tr>
        </thead>
        {list.map((item, key) => (
          <tbody>
            <tr>
              <td>{item.id}</td>
              <td>{item.title}</td>
              <td>{item.body}</td>
              <td>
                <Link
                  className="btn btn-dark btn-lg btn-block"
                  to={{ pathname: "/editData", item }}
                >
                  Edit
                </Link>
              </td>
              <td>
                <button
                  type="button"
                  onClick={() => DeleteRecord(item.id)}
                  className="btn btn-dark btn-lg btn-block"
                >
                  Delete
                </button>
              </td>
            </tr>
          </tbody>
        ))}
      </table>
    </div>
  );
}
export default connect(null, { getAlldata })(List);
